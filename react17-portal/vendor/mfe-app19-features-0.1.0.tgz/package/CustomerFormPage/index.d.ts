import type { MountFn, CustomerFormPageProps } from '../contract';
export type * from '../contract';
export declare const mount: MountFn<CustomerFormPageProps>;
export default mount;
