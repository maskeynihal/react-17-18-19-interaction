(()=>{if(typeof document==='undefined'||document.getElementById("mfe-app19-features-css"))return;const s=document.createElement('style');s.id="mfe-app19-features-css";s.textContent=".r19-root{--r19-bg:#f6f7fb;--r19-surface:#fff;--r19-border:#e3e6ef;--r19-text:#1b1f2a;--r19-muted:#5f6678;--r19-accent:#5b4cdb;--r19-accent-soft:#ece9ff;--r19-danger:#c62f3c;--r19-success:#1d7a46;--r19-free:#8a93a8;--r19-pro:#5b4cdb;--r19-enterprise:#0f8a7e;color:var(--r19-text);box-sizing:border-box;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;line-height:1.45}.r19-root[data-theme=dark]{--r19-bg:#12141b;--r19-surface:#1b1e28;--r19-border:#2c3040;--r19-text:#e8eaf2;--r19-muted:#9aa1b5;--r19-accent:#9b8fff;--r19-accent-soft:#2a2550;--r19-danger:#ff6b78;--r19-success:#58d08d;--r19-free:#8a93a8;--r19-pro:#9b8fff;--r19-enterprise:#3cc7b8}.r19-root *,.r19-root :before,.r19-root :after{box-sizing:inherit}.r19-page{gap:20px;display:grid}.r19-page-head{flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;display:flex}.r19-page-title{margin:0;font-size:1.4rem;font-weight:650}.r19-page-sub{color:var(--r19-muted);margin:2px 0 0;font-size:.9rem}.r19-card{background:var(--r19-surface);border:1px solid var(--r19-border);border-radius:12px;padding:16px 18px}.r19-card-title{margin:0 0 12px;font-size:.95rem;font-weight:600}.r19-kpis{grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;display:grid}.r19-kpi-label{color:var(--r19-muted);text-transform:uppercase;letter-spacing:.04em;font-size:.8rem}.r19-kpi-value{font-variant-numeric:tabular-nums;margin-top:4px;font-size:1.6rem;font-weight:700}.r19-kpi-trend{font-variant-numeric:tabular-nums;margin-top:2px;font-size:.8rem}.r19-kpi-trend[data-dir=up]{color:var(--r19-success)}.r19-kpi-trend[data-dir=down]{color:var(--r19-danger)}.r19-kpi-trend[data-dir=flat]{color:var(--r19-muted)}.r19-grid-2{grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;display:grid}.r19-chart{gap:10px;display:grid}.r19-bar-row{grid-template-columns:90px 1fr 32px;align-items:center;gap:10px;font-size:.85rem;display:grid}.r19-bar-track{background:var(--r19-bg);border-radius:7px;height:14px;overflow:hidden}.r19-bar-fill{border-radius:7px;height:100%;transition:width .3s}.r19-bar-fill[data-plan=free]{background:var(--r19-free)}.r19-bar-fill[data-plan=pro]{background:var(--r19-pro)}.r19-bar-fill[data-plan=enterprise]{background:var(--r19-enterprise)}.r19-bar-count{text-align:right;font-variant-numeric:tabular-nums}.r19-table{border-collapse:collapse;width:100%;font-size:.875rem}.r19-table th{text-align:left;color:var(--r19-muted);border-bottom:1px solid var(--r19-border);padding:6px 8px;font-weight:500}.r19-table td{border-bottom:1px solid var(--r19-border);padding:8px}.r19-table tr:last-child td{border-bottom:0}.r19-badge{background:var(--r19-accent-soft);color:var(--r19-accent);border-radius:999px;padding:1px 8px;font-size:.75rem;font-weight:600;display:inline-block}.r19-badge[data-plan=free]{background:var(--r19-bg);color:var(--r19-muted)}.r19-badge[data-plan=enterprise]{color:var(--r19-enterprise)}.r19-btn{appearance:none;font:inherit;cursor:pointer;background:var(--r19-accent);color:#fff;border:1px solid #0000;border-radius:8px;padding:8px 14px;font-size:.875rem;font-weight:600}.r19-btn:disabled{opacity:.6;cursor:progress}.r19-btn-ghost{color:var(--r19-text);border-color:var(--r19-border);background:0 0}.r19-form{gap:14px;max-width:480px;display:grid}.r19-field{gap:4px;display:grid}.r19-label{font-size:.85rem;font-weight:600}.r19-input{font:inherit;border:1px solid var(--r19-border);background:var(--r19-surface);color:var(--r19-text);border-radius:8px;padding:8px 10px}.r19-input[aria-invalid=true]{border-color:var(--r19-danger)}.r19-field-error{color:var(--r19-danger);font-size:.8rem}.r19-form-actions{gap:8px;display:flex}.r19-success{background:var(--r19-accent-soft);color:var(--r19-text);border-radius:8px;padding:10px 12px}.r19-stats-widget{min-width:180px;display:inline-grid}.r19-remote-loading{color:var(--r19-muted);padding:12px 0;font-size:.875rem}.r19-remote-error{border:1px solid var(--r19-danger);color:var(--r19-danger);background:var(--r19-surface);border-radius:10px;flex-wrap:wrap;align-items:center;gap:8px 12px;padding:12px 14px;display:flex}.r19-remote-error-detail{color:var(--r19-muted);flex:1;font-size:.85rem}\n/*$vite$:1*/";document.head.appendChild(s);})();
import { i as e, n as t, r as n, t as r } from "../chunks/createMount-CvGRBvrI.js";
import { n as i, o as a, t as o } from "../chunks/domain-Dip7lR3n.js";
// src/mfe/contract.ts
var s = n(), c = t();
function l(e, t) {
	window.dispatchEvent(new CustomEvent(e, { detail: t }));
}
// src/features/customers/CustomerForm.tsx
var u = e(), d = {
	status: "idle",
	values: {
		name: "",
		email: "",
		plan: ""
	},
	errors: {}
}, f = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function p(e) {
	return o.includes(e);
}
function m(e) {
	let t = {};
	return e.name.trim().length < 2 && (t.name = "Name is required (at least 2 characters)."), f.test(e.email.trim()) || (t.email = "Enter a valid email address."), p(e.plan) || (t.plan = "Choose a plan."), t;
}
function h() {
	let { pending: e } = (0, c.useFormStatus)();
	return /* @__PURE__ */ (0, u.jsx)("button", {
		type: "submit",
		className: "r19-btn",
		disabled: e,
		"data-testid": "customer-submit",
		children: e ? "Saving…" : "Create customer"
	});
}
function g({ onSubmit: e, onCancel: t }) {
	let n = (0, s.useId)(), [r, c] = (0, s.useActionState)(async (t, n) => {
		let r = {
			name: String(n.get("name") ?? ""),
			email: String(n.get("email") ?? ""),
			plan: String(n.get("plan") ?? "")
		}, i = m(r);
		if (Object.keys(i).length > 0 || !p(r.plan)) return {
			status: "error",
			values: r,
			errors: i
		};
		let o = {
			id: a("c"),
			name: r.name.trim(),
			email: r.email.trim(),
			plan: r.plan,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		try {
			await e(o);
		} catch (e) {
			return {
				status: "error",
				values: r,
				errors: {},
				submitError: e instanceof Error ? e.message : "Submit failed."
			};
		}
		return l("mfe:customer-created", o), {
			...d,
			status: "success",
			created: o
		};
	}, d), f = (e) => ({
		id: `${n}-${e}`,
		name: e,
		className: "r19-input",
		"aria-invalid": r.errors[e] ? !0 : void 0,
		"aria-describedby": r.errors[e] ? `${n}-${e}-error` : void 0,
		"data-testid": `customer-${e}`
	}), g = (e) => r.errors[e] ? /* @__PURE__ */ (0, u.jsx)("span", {
		id: `${n}-${e}-error`,
		className: "r19-field-error",
		"data-testid": `customer-${e}-error`,
		children: r.errors[e]
	}) : null;
	return /* @__PURE__ */ (0, u.jsxs)("section", {
		className: "r19-page",
		"data-testid": "customer-form-page",
		children: [/* @__PURE__ */ (0, u.jsx)("div", {
			className: "r19-page-head",
			children: /* @__PURE__ */ (0, u.jsxs)("div", { children: [/* @__PURE__ */ (0, u.jsx)("h1", {
				className: "r19-page-title",
				children: "New customer"
			}), /* @__PURE__ */ (0, u.jsx)("p", {
				className: "r19-page-sub",
				children: "Built with React 19 form actions."
			})] })
		}), /* @__PURE__ */ (0, u.jsxs)("div", {
			className: "r19-card",
			children: [
				r.status === "success" && r.created && /* @__PURE__ */ (0, u.jsxs)("p", {
					className: "r19-success",
					role: "status",
					"data-testid": "customer-success",
					children: [
						"Customer “",
						r.created.name,
						"” created."
					]
				}),
				r.submitError && /* @__PURE__ */ (0, u.jsx)("p", {
					className: "r19-field-error",
					role: "alert",
					"data-testid": "customer-submit-error",
					children: r.submitError
				}),
				/* @__PURE__ */ (0, u.jsxs)("form", {
					action: c,
					className: "r19-form",
					noValidate: !0,
					"data-testid": "customer-form",
					children: [
						/* @__PURE__ */ (0, u.jsxs)("div", {
							className: "r19-field",
							children: [
								/* @__PURE__ */ (0, u.jsx)("label", {
									className: "r19-label",
									htmlFor: `${n}-name`,
									children: "Name"
								}),
								/* @__PURE__ */ (0, u.jsx)("input", {
									...f("name"),
									type: "text",
									defaultValue: r.values.name,
									autoComplete: "organization"
								}),
								g("name")
							]
						}),
						/* @__PURE__ */ (0, u.jsxs)("div", {
							className: "r19-field",
							children: [
								/* @__PURE__ */ (0, u.jsx)("label", {
									className: "r19-label",
									htmlFor: `${n}-email`,
									children: "Email"
								}),
								/* @__PURE__ */ (0, u.jsx)("input", {
									...f("email"),
									type: "email",
									defaultValue: r.values.email,
									autoComplete: "email"
								}),
								g("email")
							]
						}),
						/* @__PURE__ */ (0, u.jsxs)("div", {
							className: "r19-field",
							children: [
								/* @__PURE__ */ (0, u.jsx)("label", {
									className: "r19-label",
									htmlFor: `${n}-plan`,
									children: "Plan"
								}),
								/* @__PURE__ */ (0, u.jsxs)("select", {
									...f("plan"),
									defaultValue: r.values.plan,
									children: [/* @__PURE__ */ (0, u.jsx)("option", {
										value: "",
										children: "Select a plan…"
									}), o.map((e) => /* @__PURE__ */ (0, u.jsx)("option", {
										value: e,
										children: i[e]
									}, e))]
								}),
								g("plan")
							]
						}),
						/* @__PURE__ */ (0, u.jsxs)("div", {
							className: "r19-form-actions",
							children: [/* @__PURE__ */ (0, u.jsx)(h, {}), t && /* @__PURE__ */ (0, u.jsx)("button", {
								type: "button",
								className: "r19-btn r19-btn-ghost",
								onClick: t,
								"data-testid": "customer-cancel",
								children: "Cancel"
							})]
						})
					]
				}, JSON.stringify(r.values) + r.status)
			]
		})]
	});
}
// src/exposed/CustomerFormPage.tsx
var _ = r("CustomerFormPage", g);
export { _ as default, _ as mount };
