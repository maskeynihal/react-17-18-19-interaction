import type { MountFn, DashboardPageProps } from '../contract';
export type * from '../contract';
export declare const mount: MountFn<DashboardPageProps>;
export default mount;
