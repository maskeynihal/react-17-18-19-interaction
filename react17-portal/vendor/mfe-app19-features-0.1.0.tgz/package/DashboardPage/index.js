(()=>{if(typeof document==='undefined'||document.getElementById("mfe-app19-features-css"))return;const s=document.createElement('style');s.id="mfe-app19-features-css";s.textContent=".r19-root{--r19-bg:#f6f7fb;--r19-surface:#fff;--r19-border:#e3e6ef;--r19-text:#1b1f2a;--r19-muted:#5f6678;--r19-accent:#5b4cdb;--r19-accent-soft:#ece9ff;--r19-danger:#c62f3c;--r19-success:#1d7a46;--r19-free:#8a93a8;--r19-pro:#5b4cdb;--r19-enterprise:#0f8a7e;color:var(--r19-text);box-sizing:border-box;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;line-height:1.45}.r19-root[data-theme=dark]{--r19-bg:#12141b;--r19-surface:#1b1e28;--r19-border:#2c3040;--r19-text:#e8eaf2;--r19-muted:#9aa1b5;--r19-accent:#9b8fff;--r19-accent-soft:#2a2550;--r19-danger:#ff6b78;--r19-success:#58d08d;--r19-free:#8a93a8;--r19-pro:#9b8fff;--r19-enterprise:#3cc7b8}.r19-root *,.r19-root :before,.r19-root :after{box-sizing:inherit}.r19-page{gap:20px;display:grid}.r19-page-head{flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;display:flex}.r19-page-title{margin:0;font-size:1.4rem;font-weight:650}.r19-page-sub{color:var(--r19-muted);margin:2px 0 0;font-size:.9rem}.r19-card{background:var(--r19-surface);border:1px solid var(--r19-border);border-radius:12px;padding:16px 18px}.r19-card-title{margin:0 0 12px;font-size:.95rem;font-weight:600}.r19-kpis{grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;display:grid}.r19-kpi-label{color:var(--r19-muted);text-transform:uppercase;letter-spacing:.04em;font-size:.8rem}.r19-kpi-value{font-variant-numeric:tabular-nums;margin-top:4px;font-size:1.6rem;font-weight:700}.r19-kpi-trend{font-variant-numeric:tabular-nums;margin-top:2px;font-size:.8rem}.r19-kpi-trend[data-dir=up]{color:var(--r19-success)}.r19-kpi-trend[data-dir=down]{color:var(--r19-danger)}.r19-kpi-trend[data-dir=flat]{color:var(--r19-muted)}.r19-grid-2{grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;display:grid}.r19-chart{gap:10px;display:grid}.r19-bar-row{grid-template-columns:90px 1fr 32px;align-items:center;gap:10px;font-size:.85rem;display:grid}.r19-bar-track{background:var(--r19-bg);border-radius:7px;height:14px;overflow:hidden}.r19-bar-fill{border-radius:7px;height:100%;transition:width .3s}.r19-bar-fill[data-plan=free]{background:var(--r19-free)}.r19-bar-fill[data-plan=pro]{background:var(--r19-pro)}.r19-bar-fill[data-plan=enterprise]{background:var(--r19-enterprise)}.r19-bar-count{text-align:right;font-variant-numeric:tabular-nums}.r19-table{border-collapse:collapse;width:100%;font-size:.875rem}.r19-table th{text-align:left;color:var(--r19-muted);border-bottom:1px solid var(--r19-border);padding:6px 8px;font-weight:500}.r19-table td{border-bottom:1px solid var(--r19-border);padding:8px}.r19-table tr:last-child td{border-bottom:0}.r19-badge{background:var(--r19-accent-soft);color:var(--r19-accent);border-radius:999px;padding:1px 8px;font-size:.75rem;font-weight:600;display:inline-block}.r19-badge[data-plan=free]{background:var(--r19-bg);color:var(--r19-muted)}.r19-badge[data-plan=enterprise]{color:var(--r19-enterprise)}.r19-btn{appearance:none;font:inherit;cursor:pointer;background:var(--r19-accent);color:#fff;border:1px solid #0000;border-radius:8px;padding:8px 14px;font-size:.875rem;font-weight:600}.r19-btn:disabled{opacity:.6;cursor:progress}.r19-btn-ghost{color:var(--r19-text);border-color:var(--r19-border);background:0 0}.r19-form{gap:14px;max-width:480px;display:grid}.r19-field{gap:4px;display:grid}.r19-label{font-size:.85rem;font-weight:600}.r19-input{font:inherit;border:1px solid var(--r19-border);background:var(--r19-surface);color:var(--r19-text);border-radius:8px;padding:8px 10px}.r19-input[aria-invalid=true]{border-color:var(--r19-danger)}.r19-field-error{color:var(--r19-danger);font-size:.8rem}.r19-form-actions{gap:8px;display:flex}.r19-success{background:var(--r19-accent-soft);color:var(--r19-text);border-radius:8px;padding:10px 12px}.r19-stats-widget{min-width:180px;display:inline-grid}.r19-remote-loading{color:var(--r19-muted);padding:12px 0;font-size:.875rem}.r19-remote-error{border:1px solid var(--r19-danger);color:var(--r19-danger);background:var(--r19-surface);border-radius:10px;flex-wrap:wrap;align-items:center;gap:8px 12px;padding:12px 14px;display:flex}.r19-remote-error-detail{color:var(--r19-muted);flex:1;font-size:.85rem}\n/*$vite$:1*/";document.head.appendChild(s);})();
import { a as e, i as t, n, r, t as i } from "../chunks/domain-Dip7lR3n.js";
import { t as a } from "../chunks/StatsCard-BW-WFRI0.js";
import { i as o, t as s } from "../chunks/createMount-CvGRBvrI.js";
// src/features/dashboard/Dashboard.tsx
var c = o();
function l({ customers: o, currentUser: s, navigate: l, aside: u }) {
	let d = t(o), f = Math.max(1, ...i.map((e) => d[e])), p = [...o].sort((e, t) => t.createdAt.localeCompare(e.createdAt)).slice(0, 5);
	return /* @__PURE__ */ (0, c.jsxs)("section", {
		className: "r19-page",
		"data-testid": "dashboard",
		children: [
			/* @__PURE__ */ (0, c.jsxs)("div", {
				className: "r19-page-head",
				children: [/* @__PURE__ */ (0, c.jsxs)("div", { children: [/* @__PURE__ */ (0, c.jsx)("h1", {
					className: "r19-page-title",
					children: "Customer dashboard"
				}), s && /* @__PURE__ */ (0, c.jsxs)("p", {
					className: "r19-page-sub",
					children: ["Welcome back, ", s.name]
				})] }), /* @__PURE__ */ (0, c.jsx)("button", {
					type: "button",
					className: "r19-btn",
					"data-testid": "dashboard-new-customer",
					onClick: () => l("/customers/new"),
					children: "New customer"
				})]
			}),
			/* @__PURE__ */ (0, c.jsxs)("div", {
				className: "r19-kpis",
				children: [
					/* @__PURE__ */ (0, c.jsx)(a, {
						testId: "kpi-total",
						label: "Total customers",
						value: o.length
					}),
					/* @__PURE__ */ (0, c.jsx)(a, {
						testId: "kpi-mrr",
						label: "MRR",
						value: e(r(o))
					}),
					i.map((e) => /* @__PURE__ */ (0, c.jsx)(a, {
						testId: `kpi-plan-${e}`,
						label: n[e],
						value: d[e]
					}, e))
				]
			}),
			/* @__PURE__ */ (0, c.jsxs)("div", {
				className: "r19-grid-2",
				children: [/* @__PURE__ */ (0, c.jsxs)("div", {
					className: "r19-card",
					children: [/* @__PURE__ */ (0, c.jsx)("h2", {
						className: "r19-card-title",
						children: "Customers by plan"
					}), /* @__PURE__ */ (0, c.jsx)("div", {
						className: "r19-chart",
						"data-testid": "plan-chart",
						role: "img",
						"aria-label": "Customers by plan",
						children: i.map((e) => /* @__PURE__ */ (0, c.jsxs)("div", {
							className: "r19-bar-row",
							children: [
								/* @__PURE__ */ (0, c.jsx)("span", { children: n[e] }),
								/* @__PURE__ */ (0, c.jsx)("div", {
									className: "r19-bar-track",
									children: /* @__PURE__ */ (0, c.jsx)("div", {
										className: "r19-bar-fill",
										"data-plan": e,
										style: { width: `${d[e] / f * 100}%` }
									})
								}),
								/* @__PURE__ */ (0, c.jsx)("span", {
									className: "r19-bar-count",
									children: d[e]
								})
							]
						}, e))
					})]
				}), u]
			}),
			/* @__PURE__ */ (0, c.jsxs)("div", {
				className: "r19-card",
				children: [/* @__PURE__ */ (0, c.jsx)("h2", {
					className: "r19-card-title",
					children: "Recent customers"
				}), /* @__PURE__ */ (0, c.jsxs)("table", {
					className: "r19-table",
					"data-testid": "recent-customers",
					children: [/* @__PURE__ */ (0, c.jsx)("thead", { children: /* @__PURE__ */ (0, c.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, c.jsx)("th", { children: "Name" }),
						/* @__PURE__ */ (0, c.jsx)("th", { children: "Email" }),
						/* @__PURE__ */ (0, c.jsx)("th", { children: "Plan" }),
						/* @__PURE__ */ (0, c.jsx)("th", { children: "Joined" })
					] }) }), /* @__PURE__ */ (0, c.jsx)("tbody", { children: p.map((e) => /* @__PURE__ */ (0, c.jsxs)("tr", {
						"data-testid": "recent-customer-row",
						children: [
							/* @__PURE__ */ (0, c.jsx)("td", { children: e.name }),
							/* @__PURE__ */ (0, c.jsx)("td", { children: e.email }),
							/* @__PURE__ */ (0, c.jsx)("td", { children: /* @__PURE__ */ (0, c.jsx)("span", {
								className: "r19-badge",
								"data-plan": e.plan,
								children: n[e.plan]
							}) }),
							/* @__PURE__ */ (0, c.jsx)("td", { children: new Date(e.createdAt).toLocaleDateString("en-US") })
						]
					}, e.id)) })]
				})]
			})
		]
	});
}
// src/exposed/DashboardPage.tsx
var u = s("DashboardPage", l);
export { u as default, u as mount };
