import type { MountFn, StatsWidgetProps } from '../contract';
export type * from '../contract';
export declare const mount: MountFn<StatsWidgetProps>;
export default mount;
