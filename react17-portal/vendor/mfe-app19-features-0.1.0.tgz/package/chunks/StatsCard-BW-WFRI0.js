import { i as e } from "./createMount-CvGRBvrI.js";
// src/features/stats/StatsCard.tsx
var t = e();
function n(e) {
	return e > 0 ? "up" : e < 0 ? "down" : "flat";
}
function r({ label: e, value: r, trend: i, testId: a }) {
	let o = typeof r == "number" ? r.toLocaleString("en-US") : r;
	return /* @__PURE__ */ (0, t.jsxs)("div", {
		className: "r19-card r19-stats-card",
		"data-testid": a,
		children: [
			/* @__PURE__ */ (0, t.jsx)("div", {
				className: "r19-kpi-label",
				children: e
			}),
			/* @__PURE__ */ (0, t.jsx)("div", {
				className: "r19-kpi-value",
				"data-testid": a ? `${a}-value` : void 0,
				children: o
			}),
			i !== void 0 && /* @__PURE__ */ (0, t.jsxs)("div", {
				className: "r19-kpi-trend",
				"data-dir": n(i),
				"data-testid": a ? `${a}-trend` : void 0,
				children: [
					i > 0 ? "▲" : i < 0 ? "▼" : "•",
					" ",
					Math.abs(i).toFixed(1),
					"%"
				]
			})
		]
	});
}
export { r as t };
