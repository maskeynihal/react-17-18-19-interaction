// src/domain.ts
var e = {
	free: 0,
	pro: 49,
	enterprise: 499
}, t = [
	"free",
	"pro",
	"enterprise"
], n = {
	free: "Free",
	pro: "Pro",
	enterprise: "Enterprise"
};
function r(t) {
	return t.reduce((t, n) => t + e[n.plan], 0);
}
function i(e) {
	let t = {
		free: 0,
		pro: 0,
		enterprise: 0
	};
	for (let n of e) t[n.plan] += 1;
	return t;
}
function a(e) {
	return new Intl.NumberFormat("en-US", {
		style: "currency",
		currency: "USD",
		maximumFractionDigits: 0
	}).format(e);
}
function o(e) {
	return `${e}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}
export { a, i, n, o, r, t };
