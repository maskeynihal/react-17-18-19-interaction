import type { MountFn, ProfileCardProps } from '../contract';
export type * from '../contract';
export declare const mount: MountFn<ProfileCardProps>;
export default mount;
