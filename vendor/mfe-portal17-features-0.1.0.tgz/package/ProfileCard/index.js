(()=>{if(typeof document==='undefined'||document.getElementById("mfe-portal17-features-css"))return;const s=document.createElement('style');s.id="mfe-portal17-features-css";s.textContent=".r17-mfe-root{color:#222;font-family:Tahoma,Verdana,Geneva,sans-serif;font-size:13px}.r17-mfe-root[data-theme=dark]{color:#e8e8e8;background:#1f2633;padding:8px}.r17-mfe-root[data-theme=dark] .r17-table th{color:#fff;background:#34405a}.r17-mfe-root[data-theme=dark] .r17-table td{border-color:#3d4860}.r17-input{font:inherit;color:#222;background:#fff;border:1px solid #7f8a9b;border-radius:0;min-width:220px;padding:3px 5px}.r17-input[aria-invalid=true]{background:#fff5f5;border-color:#b00020}.r17-btn{font:inherit;color:#222;cursor:pointer;background:linear-gradient(#fff,#d9dee6);border:1px solid #6b7686;padding:3px 12px}.r17-btn:hover{background:linear-gradient(#fff,#c9d1dd)}.r17-btn--primary{color:#fff;background:linear-gradient(#4a6ea8,#2c4a7a);border-color:#1b2f4e}.r17-btn--primary:hover{background:linear-gradient(#5a7eb8,#2c4a7a)}.r17-table{border-collapse:collapse;width:100%;font-size:13px}.r17-table th{text-align:left;background:#d9dee6;border:1px solid #9aa5b5;padding:4px 6px}.r17-table td{border:1px solid #c5ccd6;padding:4px 6px}.r17-table tbody tr:nth-child(2n){background:#f6f7f9}.r17-profile-card{color:#222;background:linear-gradient(#fdfdfd,#eef1f5);border:1px solid #9aa5b5;grid-template-columns:56px 1fr;gap:4px 12px;max-width:360px;padding:12px;font-family:Tahoma,Verdana,Geneva,sans-serif;font-size:13px;display:grid;box-shadow:1px 1px #c5ccd6}.r17-profile-card__avatar{color:#fff;background:#2c4a7a;border:1px solid #1b2f4e;justify-content:center;align-items:center;width:56px;height:56px;font-size:20px;font-weight:700;display:flex}.r17-profile-card__name{font-size:15px;font-weight:700}.r17-profile-card__email{color:#555;margin-bottom:4px}.r17-profile-card__footer{color:#777;border-top:1px solid #c5ccd6;grid-column:1/-1;padding-top:4px;font-size:11px}.r17-form{max-width:420px}.r17-form__row{flex-direction:column;margin-bottom:10px;display:flex}.r17-form__row label{margin-bottom:2px;font-weight:700}.r17-form__error{color:#b00020;margin-top:2px;font-size:12px}.r17-form__actions{align-items:center;gap:12px;display:flex}.r17-form__saved{color:#1e7b34;font-weight:700}.r17-users__toolbar{justify-content:space-between;align-items:center;gap:12px;margin-bottom:8px;display:flex}.r17-users__title{margin:0;font-size:16px}.r17-users__count{color:#666;font-size:12px}.r17-table__row{cursor:pointer}.r17-table__row:hover,.r17-table__row:focus{background:#eef3fb;outline:none}.r17-table__row--selected,.r17-table__row--selected:hover{background:#ffe9a8;font-weight:700}.r17-table__empty{text-align:center;color:#777;font-style:italic}.r17-role{text-transform:uppercase;border:1px solid #999;padding:0 6px;font-size:11px;display:inline-block}.r17-role--admin{background:#f6d5d5}.r17-role--editor{background:#d9e8f7}.r17-role--viewer{background:#e5e5e5}\n/*$vite$:1*/";document.head.appendChild(s);})();
import { i as e, n as t, r as n, t as r } from "../chunks/jsx-runtime-6mMomwyt.js";
n();
var i = /* @__PURE__ */ e(t(), 1), a = r();
function o(e) {
	return e.split(/\s+/).filter(Boolean).slice(0, 2).map((e) => e[0].toUpperCase()).join("");
}
function s({ user: e }) {
	return /* @__PURE__ */ (0, a.jsxs)("div", {
		className: "r17-profile-card",
		"data-testid": "profile-card",
		"data-user-id": e.id,
		children: [
			/* @__PURE__ */ (0, a.jsx)("div", {
				className: "r17-profile-card__avatar",
				"aria-hidden": "true",
				children: o(e.name)
			}),
			/* @__PURE__ */ (0, a.jsxs)("div", {
				className: "r17-profile-card__body",
				children: [
					/* @__PURE__ */ (0, a.jsx)("div", {
						className: "r17-profile-card__name",
						"data-testid": "profile-card-name",
						children: e.name
					}),
					/* @__PURE__ */ (0, a.jsx)("div", {
						className: "r17-profile-card__email",
						children: e.email
					}),
					/* @__PURE__ */ (0, a.jsx)("span", {
						className: `r17-role r17-role--${e.role}`,
						children: e.role
					})
				]
			}),
			/* @__PURE__ */ (0, a.jsxs)("div", {
				className: "r17-profile-card__footer",
				children: [
					"React ",
					"17.0.2",
					" · Legacy Portal"
				]
			})
		]
	});
}
// src/exposed/ProfileCard.tsx
function c(e) {
	return /* @__PURE__ */ (0, a.jsx)("div", {
		className: "r17-mfe-root",
		"data-mfe": "ProfileCard",
		"data-react-version": "17.0.2",
		"data-theme": e.theme,
		children: /* @__PURE__ */ (0, a.jsx)(s, { user: e.user })
	});
}
var l = (e, t) => (i.render(/* @__PURE__ */ (0, a.jsx)(c, { ...t }), e), {
	update(t) {
		i.render(/* @__PURE__ */ (0, a.jsx)(c, { ...t }), e);
	},
	unmount() {
		i.unmountComponentAtNode(e);
	}
});
export { l as default, l as mount };
