import type { MountFn, UsersPageProps } from '../contract';
export type * from '../contract';
export declare const mount: MountFn<UsersPageProps>;
export default mount;
